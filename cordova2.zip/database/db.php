<?php
    header("Access-Control-Allow-Origin: *");
    $con =  mysqli_connect("localhost", "id12804463_deaofitas", "deaofitas", "id12804463_akademik");
?>